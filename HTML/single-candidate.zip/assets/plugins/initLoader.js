window.onload = function() {
	preloaderDK({
		el: '#preloaderDK',
		showTextBlock: true,
		showProgressBar: true
	})
}